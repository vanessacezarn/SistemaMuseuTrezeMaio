package eglv.sistemagerenciamentoacervos.controller;

public class LeitorController {
}
