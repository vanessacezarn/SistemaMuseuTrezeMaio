package eglv.sistemagerenciamentoacervos.dao;

public class LeitorDAO {
}
