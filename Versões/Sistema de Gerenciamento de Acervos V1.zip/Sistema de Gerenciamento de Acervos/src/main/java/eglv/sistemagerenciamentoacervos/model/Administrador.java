package eglv.sistemagerenciamentoacervos.model;

public class Administrador {
}
