package eglv.sistemagerenciamentoacervos.controller;

public class AdministradorController {
}
