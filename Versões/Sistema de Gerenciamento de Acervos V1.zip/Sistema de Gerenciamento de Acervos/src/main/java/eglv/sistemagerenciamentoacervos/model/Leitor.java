package eglv.sistemagerenciamentoacervos.model;

public class Leitor {
}
