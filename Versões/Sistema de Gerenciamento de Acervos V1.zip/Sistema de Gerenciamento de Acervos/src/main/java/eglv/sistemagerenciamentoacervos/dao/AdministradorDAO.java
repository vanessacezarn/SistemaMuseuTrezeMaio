package eglv.sistemagerenciamentoacervos.dao;

public class AdministradorDAO {
}
